//
//  ViewController.swift
//  Exercicio_Tableview
//
//  Created by Usuário Convidado on 16/08/17.
//  Copyright © 2017 Julio Cesar Schincariol Filho. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

