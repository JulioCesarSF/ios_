//
//  DetalheViewController.swift
//  Exercicio_Tableview
//
//  Created by Usuário Convidado on 16/08/17.
//  Copyright © 2017 Julio Cesar Schincariol Filho. All rights reserved.
//

import UIKit

class DetalheViewController: UIViewController {

    @IBOutlet weak var lblTitulo: UILabel!
    var tituloTexto:String = ""
    
    @IBOutlet weak var lblAno: UILabel!
    var descricaoTexto:String = ""
    
    @IBOutlet weak var imgFilme: UIImageView!
    var imgSelecionado:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        lblTitulo.text = tituloTexto
        lblAno.text = descricaoTexto
        imgFilme.image = UIImage(named: imgSelecionado)
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
